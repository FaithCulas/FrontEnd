import React from "react";
import logo from "./logo.svg";
import "./App.css";
import MovieList from "./components/component";
import NavBar from "./components/navbar";
import ActivityRecognition from "./components/activity";
import Authenticate from "./components/auth";
import Localization from "./components/localization";

function App() {
  return (
    <main>
      <div>
        <NavBar />
      </div>
      <div className="container-fluid ">
        <div className="row">
          <div className="col" style={{ justifyContent: "center" }}>
            <ActivityRecognition />
          </div>
          <div className="col">
            <Authenticate />
            <Localization />
          </div>
        </div>
      </div>
    </main>
  );
}

export default App;
