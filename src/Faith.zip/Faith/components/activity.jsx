import React, { Component } from "react";
class ActivityRecognition extends Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      items: [],
    };
  }

  componentDidMount() {
    fetch("https://api.example.com/items")
      .then((res) => res.json())
      .then(
        (result) => {
          this.setState({
            isLoaded: true,
            items: result.items,
          });
        },
        // Note: it's important to handle errors here
        // instead of a catch() block so that we don't swallow
        // exceptions from actual bugs in components.
        (error) => {
          this.setState({
            isLoaded: true,
            error,
          });
        }
      );
  }
  render() {
    console.log(this.state.items);
    const authStye = {
      color: "black",
      backgroundColor: "#f5f5f5",
      width: "100%",
      height: "80vh",
      alighnContent: "center",
      paddingTop: "30vh",
      marginTop: "5vh",
      textAlign: "center",
      boxShadow: "5px 5px 5px #9E9E9E",
      margin: "10 10 0 0",
    };
    return (
      <div style={authStye}>
        <h1> Activity: </h1>
      </div>
    );
  }
}

export default ActivityRecognition;
